"""Thin REST controllers."""


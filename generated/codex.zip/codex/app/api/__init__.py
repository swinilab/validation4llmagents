"""HTTP API definition."""


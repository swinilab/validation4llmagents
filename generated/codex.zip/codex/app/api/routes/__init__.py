"""Versioned FastAPI routers."""


"""OMS automated verification suite."""

